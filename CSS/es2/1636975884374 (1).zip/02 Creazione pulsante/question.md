Crea un pulsante che mostra/nasconde le righe con classe `expandable`.
Il pulsante deve avere
 - Righe nascoste
   - Colore: #ff8888
   - Testo: Mostra righe
 - Righe visibili
   - Colore: #88ff88
   - Testo: Nascondi righe
