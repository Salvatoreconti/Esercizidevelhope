Crea una sidebar che abbia come componenti:
 1. Uno spazio, placeholder, per il logo in alto;
 2. 4 link per la navigazione subito dopo il logo;
 3. Avatar e nome utente in colonna, centrati in fondo;
La sidebar deve avere dimensioni pari a 200px in larghezza e il 100% in altezza.
I link devono avere colore #2b2b2b e cambiare in #2b2bb2 al passaggio del mouse, con una transizione di 0.3 secondi;
Usa flexbox per gestire il layout.