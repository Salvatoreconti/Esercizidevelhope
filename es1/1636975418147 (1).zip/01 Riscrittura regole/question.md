Riscrivi le regole utilizzando custom properties.
