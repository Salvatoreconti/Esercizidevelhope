Aggiungi alla pagina:
 - Un pulsante disabilitato
 - Un input numerico, con relativa label, nel range 0-100 e con step di 2
 - Una checkbox con relativa label
 - Un input per date con una proprietà custom

La checkbox deve essere già selezionata all'apertura della pagina.
L'input numerico deve avere il focus all'apertura della pagina.
